import * as THREE from 'three';
import { Weapon, WeaponType } from './Weapon';
import { Hands } from './Hands';
import { soundSystem } from './SoundSystem';

// Cached materials for dropped items to avoid per-drop GPU allocations
const DROPPED_ITEM_GLOW_MAT = new THREE.MeshStandardMaterial({
  color: 0x00ff88,
  emissive: 0x00ff88,
  emissiveIntensity: 0.6,
  transparent: true,
  opacity: 0.7,
});

const DROPPED_ITEM_DEFAULT_MAT = new THREE.MeshStandardMaterial({
  color: 0x888888,
  roughness: 0.6,
});

// Cached materials for dropped weapon models
const DROPPED_WEAPON_METAL_MAT = new THREE.MeshStandardMaterial({
  color: 0x2a2a2a,
  roughness: 0.4,
  metalness: 0.8,
});

const DROPPED_WEAPON_WOOD_MAT = new THREE.MeshStandardMaterial({
  color: 0x8b4513,
  roughness: 0.8,
  metalness: 0.1,
});

export interface CombatState {
  hp: number;
  maxHp: number;
  hasWeapon: boolean;
  ammo: number;
  maxAmmo: number;
  isDead: boolean;
  isReloading: boolean;
  armorHp: number;
  maxArmorHp: number;
  armorEquipped: boolean;
}

export type CombatTeam = 'guard' | 'prisoner';

export interface CombatOptions {
  spawnDefaultWeapons?: boolean;
  team?: CombatTeam;
}

export class Combat {
  private camera: THREE.Camera;
  private scene: THREE.Scene;
  private team: CombatTeam;
  private mapColliders: THREE.Box3[] = [];
  
  public weapon: Weapon | null = null;
  public hands: Hands;
  public droppedWeapons: THREE.Group[] = [];
  public droppedItems: THREE.Group[] = [];
  
  private hp = 100;
  private maxHp = 100;
  private isDead = false;

  // Armor system
  private armorHp = 0;
  private maxArmorHp = 50;
  private armorEquipped = false;
  
  // Состояние атаки
  private isPunching = false;
  private punchCooldown = 0;
  public punchDamage = 20;
  private punchRange = 2;
  private punchCooldownTime = 0.5; // секунды между ударами
  
  private storedWeapon: Weapon | null = null;

  // VFX tracking
  private bulletHoles: THREE.Group[] = [];
  private impactParticles: THREE.Mesh[] = [];
  private tracers: THREE.Mesh[] = [];
  private shellCasings: THREE.Mesh[] = [];

  // Item system
  public heldItemType: string = 'none';
  private flashlightOn = false;
  private flashlight: THREE.SpotLight | null = null;
  private isUsingConsumable = false;
  private consumableTimer = 0;
  private consumableDuration = 0;
  private consumableType: string = '';
  private shieldEquipped = false;
  private bandageRegenTimer = 0;
  private bandageRegenActive = false;
  private bandageHealAccumulator = 0;

  // Callbacks
  public onStateChange?: (state: CombatState) => void;
  public onHit?: (damage: number) => void;
  public onDeath?: () => void;
  public onCameraRecoil?: (pitch: number, yaw: number) => void;
  public onWeaponPickedUp?: (weaponName: string) => void;
  public onWeaponDropped?: (weaponType: WeaponType) => void;
  public onItemUsed?: (itemId: string) => void;
  public onItemDropped?: (itemId: string) => void;
  public onGlassHit?: (glassMesh: THREE.Mesh) => void;

  // Progressive recoil tracking
  private consecutiveShots = 0;
  private lastShotTime = 0;

  // Semi-auto tracking
  private semiAutoFired = false;

  // Movement state for dynamic spread
  private _isMoving = false;
  private _isSprinting = false;
  private _isCrouching = false;
  
  private boundMouseDown = this.onMouseDown.bind(this);
  private boundMouseUp = this.onMouseUp.bind(this);
  private boundKeyDown = this.onKeyDown.bind(this);
  private isMouseDown = false;

  constructor(
    camera: THREE.Camera,
    scene: THREE.Scene,
    hands: Hands,
    options: CombatOptions = {}
  ) {
    this.camera = camera;
    this.scene = scene;
    this.hands = hands;
    this.team = options.team || 'prisoner';
    
    this.setupInput();

    if (options.spawnDefaultWeapons !== false) {
      // Оружие в оружейной для подбора зеками при бунте
      this.createDroppedWeapon(new THREE.Vector3(9, 1, 0));
      this.createDroppedWeapon(new THREE.Vector3(9, 1, 2));
      this.createDroppedWeapon(new THREE.Vector3(9, 1, 4));
    }
  }

  setMapColliders(colliders: THREE.Box3[]) {
    this.mapColliders = colliders;
  }

  setMovementState(moving: boolean, sprinting: boolean, crouching: boolean) {
    this._isMoving = moving;
    this._isSprinting = sprinting;
    this._isCrouching = crouching;
  }

  // Give weapon to player (for guards at spawn)
  giveWeapon(weaponType: WeaponType = 'ak47') {
    if (this.weapon) return;
    
    this.weapon = new Weapon(this.team, weaponType);
    this.camera.add(this.weapon.group);
    this.hands.setVisible(false);
    this.notifyStateChange();
    this.onWeaponPickedUp?.(this.weapon.stats.name);
  }

  // Create pickable weapon at specified position
  createDroppedWeaponAt(position: THREE.Vector3, weaponType: WeaponType = 'ak47') {
    this.createDroppedWeapon(position, weaponType);
  }

  // Убрать оружие у игрока (при респавне зека)
  removeWeapon() {
    if (!this.weapon) return;
    
    this.camera.remove(this.weapon.group);
    this.weapon = null;
    this.hands.setVisible(true);
    this.notifyStateChange();
  }

  // Put away weapon (hide from camera but keep reference for inventory)
  putAwayWeapon() {
    if (!this.weapon) return;
    this.camera.remove(this.weapon.group);
    this.storedWeapon = this.weapon;
    this.weapon = null;
    this.hands.setVisible(true);
    this.notifyStateChange();
  }

  // Take out stored weapon (re-attach to camera)
  takeOutWeapon() {
    if (!this.storedWeapon) return;
    this.weapon = this.storedWeapon;
    this.storedWeapon = null;
    this.camera.add(this.weapon.group);
    this.hands.setVisible(false);
    this.notifyStateChange();
  }

  private setupInput() {
    document.addEventListener('mousedown', this.boundMouseDown);
    document.addEventListener('mouseup', this.boundMouseUp);
    document.addEventListener('keydown', this.boundKeyDown);
  }

  private onMouseDown(event: MouseEvent) {
    if (document.pointerLockElement === null) return;
    
    if (event.button === 0) { // ЛКМ
      this.isMouseDown = true;
      if (this.weapon) {
        this.shoot();
      } else if (this.heldItemType === 'item_shiv') {
        this.meleeAttack('shiv');
      } else if (this.heldItemType === 'item_baton') {
        this.meleeAttack('baton');
      } else if (this.heldItemType === 'item_flashlight') {
        this.toggleFlashlight();
      } else if (this.heldItemType === 'item_shield') {
        // Shield has no attack action on click
      } else if (this.heldItemType === 'item_medkit') {
        this.useConsumable('item_medkit');
      } else if (this.heldItemType === 'item_bandage') {
        this.useConsumable('item_bandage');
      } else {
        this.punch();
      }
    }
  }

  private onMouseUp(event: MouseEvent) {
    if (event.button === 0) {
      this.isMouseDown = false;
      this.semiAutoFired = false;
    }
  }

  private onKeyDown(event: KeyboardEvent) {
    if (document.pointerLockElement === null) return;
    
    switch (event.code) {
      case 'KeyE':
        this.tryPickupWeapon();
        break;
      case 'KeyG':
        if (this.weapon || this.storedWeapon) {
          this.dropWeapon();
        } else {
          this.dropItem();
        }
        break;
      case 'KeyR':
        if (this.weapon && !this.weapon.isCurrentlyReloading() && this.weapon.stats.currentAmmo < this.weapon.stats.maxAmmo) {
          this.weapon.reload();
          soundSystem.playReload();
          this.notifyStateChange();
        }
        break;
    }
  }

  private punch() {
    if (this.isPunching || this.punchCooldown > 0 || this.isDead) return;
    
    this.isPunching = true;
    this.punchCooldown = this.punchCooldownTime;
    
    // Звук удара
    soundSystem.playPunch();
    
    // Анимация удара через hands
    this.hands.startPunch();
    
    // Проверка попадания (raycast от камеры)
    setTimeout(() => {
      this.checkPunchHit();
      this.isPunching = false;
    }, 150);
  }

  private checkPunchHit() {
    const raycaster = new THREE.Raycaster();
    const direction = new THREE.Vector3();
    this.camera.getWorldDirection(direction);
    
    raycaster.set(this.camera.position, direction);
    raycaster.far = this.punchRange;
    
    // Check if hit glass
    const intersects = raycaster.intersectObjects(this.scene.children, true);
    if (intersects.length > 0) {
      let hitObj: THREE.Object3D | null = intersects[0].object;
      while (hitObj) {
        if (hitObj.userData?.isGlass) {
          this.onGlassHit?.(hitObj as THREE.Mesh);
          break;
        }
        hitObj = hitObj.parent;
      }
    }
  }

  private shoot() {
    if (!this.weapon || this.isDead) return;

    const wType = this.weapon.weaponType;

    // Semi-auto: only fire once per click
    if (wType === 'pistol' && this.semiAutoFired) return;
    // Pump: block during pump
    if (wType === 'shotgun' && this.weapon.isPumping) return;

    // For shotgun, allow interrupting reload to fire
    if (this.weapon.isCurrentlyReloading() && wType === 'shotgun') {
      if (!this.weapon.interruptReload()) return;
    }

    const result = this.weapon.fire();
    if (result.fired) {
      // Mark semi-auto as fired
      if (wType === 'pistol') this.semiAutoFired = true;

      // Play weapon-specific sounds
      if (wType === 'ak47') {
        soundSystem.playGunshot();
        setTimeout(() => soundSystem.playMechanicalCycle(), 80);
      } else if (wType === 'shotgun') {
        soundSystem.playShotgunBlast();
        setTimeout(() => soundSystem.playShotgunPump(), 300);
      } else if (wType === 'pistol') {
        soundSystem.playPistolShot();
        setTimeout(() => soundSystem.playPistolSlide(), 50);
      } else if (wType === 'taser') {
        soundSystem.playTaserFire();
      }

      // Progressive recoil
      this.consecutiveShots++;
      this.lastShotTime = performance.now();
      const recoil = Math.min(0.08, 0.02 + this.consecutiveShots * 0.008);
      const yaw = (Math.random() - 0.5) * recoil * 0.5;
      this.onCameraRecoil?.(recoil, yaw);

      // Shell casing ejection (not for taser)
      if (wType !== 'taser') {
        this.spawnShellCasing();
      }

      if (wType === 'shotgun') {
        // Multi-pellet raycast
        for (let p = 0; p < result.pelletsPerShot; p++) {
          const raycaster = new THREE.Raycaster();
          const direction = this.weapon.getAimDirection(this.camera, this._isMoving, this._isCrouching, this._isSprinting, this.weapon.stats.spread);
          raycaster.set(this.camera.position, direction);
          raycaster.far = this.weapon.stats.range;
          const intersects = raycaster.intersectObjects(this.scene.children, true);
          if (intersects.length > 0) {
            const hit = intersects[0];
            let hitObj: THREE.Object3D | null = hit.object;
            while (hitObj) {
              if (hitObj.userData?.isGlass) { this.onGlassHit?.(hitObj as THREE.Mesh); break; }
              hitObj = hitObj.parent;
            }
            this.createBulletHole(hit.point, hit.face?.normal);
            this.createTracer(hit.point);
          }
        }
      } else if (wType === 'taser') {
        // Taser: range check, apply damage on hit and show spark VFX
        const raycaster = new THREE.Raycaster();
        const direction = this.weapon.getAimDirection(this.camera, this._isMoving, this._isCrouching, this._isSprinting, 0);
        raycaster.set(this.camera.position, direction);
        raycaster.far = this.weapon.stats.range;
        const intersects = raycaster.intersectObjects(this.scene.children, true);
        if (intersects.length > 0) {
          const hit = intersects[0];
          let hitObj: THREE.Object3D | null = hit.object;
          while (hitObj) {
            if (hitObj.userData?.isGlass) { this.onGlassHit?.(hitObj as THREE.Mesh); break; }
            hitObj = hitObj.parent;
          }
          // Visual feedback: bullet hole at impact point
          this.createBulletHole(hit.point, hit.face?.normal);
          // Taser spark/lightning VFX at hit point
          this.spawnTaserSpark(hit.point);
        }
      } else {
        // AK-47 and Pistol: single ray
        const raycaster = new THREE.Raycaster();
        const extraSpread = Math.min(0.04, this.consecutiveShots * 0.005);
        const direction = this.weapon.getAimDirection(this.camera, this._isMoving, this._isCrouching, this._isSprinting, extraSpread);
        raycaster.set(this.camera.position, direction);
        raycaster.far = this.weapon.stats.range;
        const intersects = raycaster.intersectObjects(this.scene.children, true);
        if (intersects.length > 0) {
          const hit = intersects[0];
          let hitObj: THREE.Object3D | null = hit.object;
          while (hitObj) {
            if (hitObj.userData?.isGlass) { this.onGlassHit?.(hitObj as THREE.Mesh); break; }
            hitObj = hitObj.parent;
          }
          this.createBulletHole(hit.point, hit.face?.normal);
          this.createTracer(hit.point);
        }
      }

      this.notifyStateChange();
    } else if (this.weapon.stats.currentAmmo <= 0 && !this.weapon.isCurrentlyReloading()) {
      soundSystem.playDryFire();
    }
  }

  

  private createBulletHole(position: THREE.Vector3, normal?: THREE.Vector3) {
    const holeGroup = new THREE.Group();

    // Inner dark circle
    const innerGeo = new THREE.CircleGeometry(0.03, 8);
    const innerMat = new THREE.MeshBasicMaterial({
      color: 0x050505,
      side: THREE.DoubleSide,
    });
    const inner = new THREE.Mesh(innerGeo, innerMat);
    holeGroup.add(inner);

    // Outer ring
    const outerGeo = new THREE.RingGeometry(0.03, 0.08, 12);
    const outerMat = new THREE.MeshBasicMaterial({
      color: 0x222222,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.7,
    });
    const outer = new THREE.Mesh(outerGeo, outerMat);
    outer.position.z = -0.001; // slight offset to avoid z-fighting
    holeGroup.add(outer);

    holeGroup.position.copy(position);

    if (normal) {
      const offsetNormal = normal.clone().normalize();
      holeGroup.position.add(offsetNormal.multiplyScalar(0.01));
      holeGroup.lookAt(position.clone().add(normal));
    }

    this.scene.add(holeGroup);
    this.bulletHoles.push(holeGroup);

    // Limit to 30 bullet holes
    if (this.bulletHoles.length > 30) {
      const oldest = this.bulletHoles.shift()!;
      oldest.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          if (child.material instanceof THREE.Material) {
            child.material.dispose();
          }
        }
      });
      this.scene.remove(oldest);
    }

    // Spawn impact particles
    this.spawnImpactParticles(position, normal);
  }

  private spawnImpactParticles(position: THREE.Vector3, normal?: THREE.Vector3) {
    const particleMat = new THREE.MeshBasicMaterial({ color: 0xff6600 });
    const particleGeo = new THREE.BoxGeometry(0.01, 0.01, 0.01);

    for (let i = 0; i < 4; i++) {
      const particle = new THREE.Mesh(particleGeo, particleMat);
      particle.position.copy(position);

      // Random velocity outward from hit normal
      const dir = normal ? normal.clone().normalize() : new THREE.Vector3(0, 1, 0);
      const vx = dir.x * 2 + (Math.random() - 0.5) * 3;
      const vy = dir.y * 2 + Math.random() * 2;
      const vz = dir.z * 2 + (Math.random() - 0.5) * 3;

      particle.userData.velocityX = vx;
      particle.userData.velocityY = vy;
      particle.userData.velocityZ = vz;
      particle.userData.lifetime = 0;
      particle.userData.maxLifetime = 0.3;

      this.scene.add(particle);
      this.impactParticles.push(particle);
    }
  }

  private spawnTaserSpark(position: THREE.Vector3) {
    // Emit a short-lived lightning/sparks effect at the hit point
    const sparkGroup = new THREE.Group();
    sparkGroup.position.copy(position);

    const sparkMat = new THREE.MeshBasicMaterial({ color: 0x44ccff });
    const sparkBrightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    // Central flash
    const flashGeo = new THREE.SphereGeometry(0.06, 6, 6);
    const flash = new THREE.Mesh(flashGeo, sparkBrightMat);
    sparkGroup.add(flash);

    // Lightning bolt arms
    for (let i = 0; i < 6; i++) {
      const armGeo = new THREE.CylinderGeometry(0.005, 0.002, 0.12, 4);
      const arm = new THREE.Mesh(armGeo, sparkMat);
      arm.rotation.x = (Math.random() - 0.5) * Math.PI;
      arm.rotation.z = (Math.random() - 0.5) * Math.PI;
      arm.position.set(
        (Math.random() - 0.5) * 0.04,
        (Math.random() - 0.5) * 0.04,
        (Math.random() - 0.5) * 0.04
      );
      sparkGroup.add(arm);
    }

    this.scene.add(sparkGroup);

    // Remove after a short delay
    setTimeout(() => {
      sparkGroup.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          if (child.material instanceof THREE.Material) {
            child.material.dispose();
          }
        }
      });
      this.scene.remove(sparkGroup);
    }, 200);
  }

  private createTracer(hitPoint: THREE.Vector3) {
    if (!this.weapon) return;

    const muzzlePos = this.weapon.getMuzzleWorldPosition();
    const direction = new THREE.Vector3().subVectors(hitPoint, muzzlePos);
    const distance = direction.length();

    if (distance < 0.1) return;

    const tracerGeo = new THREE.CylinderGeometry(0.003, 0.003, distance, 4);
    const tracerMat = new THREE.MeshBasicMaterial({ color: 0xffffaa });
    const tracer = new THREE.Mesh(tracerGeo, tracerMat);

    // Position at midpoint
    const midpoint = new THREE.Vector3().addVectors(muzzlePos, hitPoint).multiplyScalar(0.5);
    tracer.position.copy(midpoint);

    // Orient along direction
    tracer.lookAt(hitPoint);
    tracer.rotateX(Math.PI / 2);

    tracer.userData.lifetime = 0;
    tracer.userData.maxLifetime = 0.08;

    this.scene.add(tracer);
    this.tracers.push(tracer);
  }

  private spawnShellCasing() {
    if (!this.weapon) return;

    const casingGeo = new THREE.CylinderGeometry(0.006, 0.006, 0.025, 6);
    const casingMat = new THREE.MeshStandardMaterial({
      color: 0xd4a017,
      metalness: 0.9,
      roughness: 0.3,
    });
    const casing = new THREE.Mesh(casingGeo, casingMat);

    // Get muzzle world position and offset to the right (ejection port)
    const muzzlePos = this.weapon.getMuzzleWorldPosition();
    const rightVec = new THREE.Vector3();
    this.camera.getWorldDirection(rightVec);
    // Camera right vector: cross forward with world up
    const forward = rightVec.clone();
    rightVec.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();

    casing.position.copy(muzzlePos).add(rightVec.clone().multiplyScalar(0.05));

    // Velocity: rightward + upward + slight random
    const vx = rightVec.x * (2 + Math.random()) + (Math.random() - 0.5) * 0.5;
    const vy = 1 + Math.random();
    const vz = rightVec.z * (2 + Math.random()) + (Math.random() - 0.5) * 0.5;

    casing.userData.velocityX = vx;
    casing.userData.velocityY = vy;
    casing.userData.velocityZ = vz;
    casing.userData.spinX = (Math.random() - 0.5) * 15;
    casing.userData.spinZ = (Math.random() - 0.5) * 15;
    casing.userData.lifetime = 3;
    casing.userData.bounced = false;

    this.scene.add(casing);
    this.shellCasings.push(casing);

    // Limit to 10 shell casings
    if (this.shellCasings.length > 10) {
      const oldest = this.shellCasings.shift()!;
      this.scene.remove(oldest);
      oldest.geometry.dispose();
      (oldest.material as THREE.Material).dispose();
    }
  }

  private createDroppedWeapon(position: THREE.Vector3, weaponType: WeaponType = 'ak47') {
    const weaponGroup = new THREE.Group();

    if (weaponType === 'ak47') {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.8), DROPPED_WEAPON_METAL_MAT);
      weaponGroup.add(body);
      const stock = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.3), DROPPED_WEAPON_WOOD_MAT);
      stock.position.set(0, 0, 0.4);
      weaponGroup.add(stock);
      const magazine = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.15, 0.1), DROPPED_WEAPON_METAL_MAT);
      magazine.position.set(0, -0.1, 0);
      weaponGroup.add(magazine);
    } else if (weaponType === 'shotgun') {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.9), DROPPED_WEAPON_METAL_MAT);
      weaponGroup.add(body);
      const stock = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.25), DROPPED_WEAPON_METAL_MAT);
      stock.position.set(0, 0, 0.5);
      weaponGroup.add(stock);
      const pump = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.06, 0.15), DROPPED_WEAPON_WOOD_MAT);
      pump.position.set(0, -0.02, -0.2);
      weaponGroup.add(pump);
    } else if (weaponType === 'pistol') {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.06, 0.2), DROPPED_WEAPON_METAL_MAT);
      weaponGroup.add(body);
      const grip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.08, 0.04), DROPPED_WEAPON_WOOD_MAT);
      grip.position.set(0, -0.06, 0.05);
      weaponGroup.add(grip);
    } else if (weaponType === 'taser') {
      const yellowMat = new THREE.MeshStandardMaterial({ color: 0xf0d000, roughness: 0.5 });
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 0.15), yellowMat);
      weaponGroup.add(body);
      const grip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.07, 0.04), DROPPED_WEAPON_METAL_MAT);
      grip.position.set(0, -0.05, 0.03);
      weaponGroup.add(grip);
    }

    weaponGroup.position.copy(position);
    weaponGroup.rotation.z = Math.PI / 2;
    weaponGroup.rotation.y = Math.random() * Math.PI;
    
    weaponGroup.userData.isWeapon = true;
    weaponGroup.userData.weaponType = weaponType;
    weaponGroup.userData.velocityY = 0;
    weaponGroup.userData.velocityX = 0;
    weaponGroup.userData.velocityZ = 0;
    weaponGroup.userData.grounded = false;
    
    this.scene.add(weaponGroup);
    this.droppedWeapons.push(weaponGroup);
  }

  private tryPickupWeapon() {
    if (this.weapon || this.storedWeapon || this.isDead) return;
    
    const playerPos = this.camera.position;
    const pickupRange = 2;
    
    for (let i = 0; i < this.droppedWeapons.length; i++) {
      const droppedWeapon = this.droppedWeapons[i];
      const dx = playerPos.x - droppedWeapon.position.x;
      const dz = playerPos.z - droppedWeapon.position.z;
      const distance = Math.sqrt(dx * dx + dz * dz);
      
      if (distance < pickupRange) {
        this.scene.remove(droppedWeapon);
        this.droppedWeapons.splice(i, 1);

        const storedType: WeaponType = droppedWeapon.userData.weaponType || 'ak47';
        this.weapon = new Weapon(this.team, storedType);
        this.camera.add(this.weapon.group);
        
        this.hands.setVisible(false);
        soundSystem.playPickup();
        
        this.notifyStateChange();
        this.onWeaponPickedUp?.(this.weapon.stats.name);
        return;
      }
    }
  }

  private dropWeapon() {
    if (this.isDead) return;

    // If weapon is holstered, take it out first so we can drop it
    if (!this.weapon && this.storedWeapon) {
      this.weapon = this.storedWeapon;
      this.storedWeapon = null;
    }

    if (!this.weapon) return;

    const droppedType = this.weapon.weaponType;
    
    // Remove weapon from camera
    this.camera.remove(this.weapon.group);
    
    // Create dropped weapon in front of player
    const dropDirection = new THREE.Vector3();
    this.camera.getWorldDirection(dropDirection);
    
    const dropPosition = this.camera.position.clone();
    dropPosition.y = this.camera.position.y - 0.5;
    const horizDir = new THREE.Vector3(dropDirection.x, 0, dropDirection.z).normalize();
    dropPosition.add(horizDir.clone().multiplyScalar(0.5));
    
    // If drop position is inside a collider, pull it back to player position
    const dropBox = new THREE.Box3(
      new THREE.Vector3(dropPosition.x - 0.1, dropPosition.y - 0.1, dropPosition.z - 0.1),
      new THREE.Vector3(dropPosition.x + 0.1, dropPosition.y + 0.1, dropPosition.z + 0.1)
    );
    for (const collider of this.mapColliders) {
      if (dropBox.intersectsBox(collider)) {
        dropPosition.copy(this.camera.position);
        dropPosition.y -= 0.5;
        break;
      }
    }
    
    this.createDroppedWeapon(dropPosition, droppedType);
    
    // Give the dropped weapon initial throw velocity
    const lastDropped = this.droppedWeapons[this.droppedWeapons.length - 1];
    lastDropped.userData.velocityY = 2;
    lastDropped.userData.velocityX = dropDirection.x * 3;
    lastDropped.userData.velocityZ = dropDirection.z * 3;
    lastDropped.userData.grounded = false;
    
    this.weapon = null;
    
    this.hands.setVisible(true);
    soundSystem.playDrop();
    
    this.notifyStateChange();
    this.onWeaponDropped?.(droppedType);
  }

  private dropItem() {
    if (this.isDead || this.heldItemType === 'none' || this.heldItemType === 'fists') return;
    if (this.isUsingConsumable) return;

    const itemType = this.heldItemType;

    // Calculate drop position (same logic as dropWeapon)
    const dropDirection = new THREE.Vector3();
    this.camera.getWorldDirection(dropDirection);
    const dropPosition = this.camera.position.clone();
    dropPosition.y = this.camera.position.y - 0.5;
    const horizDir = new THREE.Vector3(dropDirection.x, 0, dropDirection.z).normalize();
    dropPosition.add(horizDir.clone().multiplyScalar(0.5));

    // Check colliders
    const dropBox = new THREE.Box3(
      new THREE.Vector3(dropPosition.x - 0.1, dropPosition.y - 0.1, dropPosition.z - 0.1),
      new THREE.Vector3(dropPosition.x + 0.1, dropPosition.y + 0.1, dropPosition.z + 0.1)
    );
    for (const collider of this.mapColliders) {
      if (dropBox.intersectsBox(collider)) {
        dropPosition.copy(this.camera.position);
        dropPosition.y -= 0.5;
        break;
      }
    }

    this.createDroppedItemMesh(dropPosition, itemType);

    // Give throw velocity
    const lastDropped = this.droppedItems[this.droppedItems.length - 1];
    lastDropped.userData.velocityY = 2;
    lastDropped.userData.velocityX = dropDirection.x * 3;
    lastDropped.userData.velocityZ = dropDirection.z * 3;
    lastDropped.userData.grounded = false;

    // Clear equipped item
    this.unequipItem();

    // Play drop sound
    soundSystem.playDrop();

    // Notify inventory
    this.onItemDropped?.(itemType);
  }

  public createDroppedItemMesh(position: THREE.Vector3, itemType: string) {
    const itemGroup = new THREE.Group();

    switch (itemType) {
      case 'item_shiv': {
        const bladeMat = new THREE.MeshStandardMaterial({ color: 0x999999, roughness: 0.15, metalness: 0.9 });
        const tapeMat = new THREE.MeshStandardMaterial({ color: 0x444444, roughness: 0.9 });
        const blade = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.015, 0.14), bladeMat);
        itemGroup.add(blade);
        const handle = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.02, 0.08), tapeMat);
        handle.position.set(0, 0, 0.11);
        itemGroup.add(handle);
        break;
      }
      case 'item_baton': {
        const rubber = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.95 });
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.013, 0.4, 8), rubber);
        body.rotation.x = Math.PI / 2;
        itemGroup.add(body);
        break;
      }
      case 'item_shield': {
        const frameMat = new THREE.MeshStandardMaterial({ color: 0x3a3a3a, roughness: 0.3, metalness: 0.85 });
        const glassMat = new THREE.MeshStandardMaterial({ color: 0xaaddff, roughness: 0.1, transparent: true, opacity: 0.35 });
        const frame = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.6, 0.02), frameMat);
        itemGroup.add(frame);
        const panel = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.4, 0.01), glassMat);
        panel.position.set(0, 0.05, 0.01);
        itemGroup.add(panel);
        break;
      }
      case 'item_flashlight': {
        const metalDark = new THREE.MeshStandardMaterial({ color: 0x3a3a3a, roughness: 0.3, metalness: 0.85 });
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.16, 8), metalDark);
        body.rotation.x = Math.PI / 2;
        itemGroup.add(body);
        break;
      }
      case 'item_medkit': {
        const boxMat = new THREE.MeshStandardMaterial({ color: 0xeeeeee, roughness: 0.6 });
        const crossMat = new THREE.MeshStandardMaterial({ color: 0xcc2222, roughness: 0.5 });
        const box = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.1, 0.12), boxMat);
        itemGroup.add(box);
        const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.005, 0.025), crossMat);
        crossH.position.set(0, 0.051, 0);
        itemGroup.add(crossH);
        const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.005, 0.06), crossMat);
        crossV.position.set(0, 0.051, 0);
        itemGroup.add(crossV);
        break;
      }
      case 'item_bandage': {
        const bandageMat = new THREE.MeshStandardMaterial({ color: 0xf0f0f0, roughness: 0.85 });
        const roll = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.05, 12), bandageMat);
        roll.rotation.z = Math.PI / 2;
        itemGroup.add(roll);
        break;
      }
      case 'item_vest': {
        const vestMat = new THREE.MeshStandardMaterial({ color: 0x556b2f, roughness: 0.8 });
        const strapMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2a, roughness: 0.9 });
        const body = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.2, 0.08), vestMat);
        itemGroup.add(body);
        const strapL = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.28, 0.02), strapMat);
        strapL.position.set(-0.08, 0.04, 0);
        itemGroup.add(strapL);
        const strapR = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.28, 0.02), strapMat);
        strapR.position.set(0.08, 0.04, 0);
        itemGroup.add(strapR);
        break;
      }
      default: {
        const defaultBox = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.35, 0.35), DROPPED_ITEM_DEFAULT_MAT);
        itemGroup.add(defaultBox);
        break;
      }
    }

    // Add glow beacon for visibility
    const glowRing = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.02, 8, 16), DROPPED_ITEM_GLOW_MAT);
    glowRing.rotation.x = Math.PI / 2;
    glowRing.position.y = -0.05;
    itemGroup.add(glowRing);

    itemGroup.position.copy(position);
    itemGroup.rotation.y = Math.random() * Math.PI;

    itemGroup.userData.isItem = true;
    itemGroup.userData.itemType = itemType;
    itemGroup.userData.velocityY = 0;
    itemGroup.userData.velocityX = 0;
    itemGroup.userData.velocityZ = 0;
    itemGroup.userData.grounded = false;

    this.scene.add(itemGroup);
    this.droppedItems.push(itemGroup);
  }

  public tryPickupItem(camera: THREE.Camera): { picked: boolean; itemType: string } | null {
    const playerPos = camera.position;
    const pickupRange = 2;
    const maxYDistance = 2;

    for (let i = 0; i < this.droppedItems.length; i++) {
      const item = this.droppedItems[i];
      if (Math.abs(playerPos.y - item.position.y) > maxYDistance) continue;
      const dx = playerPos.x - item.position.x;
      const dz = playerPos.z - item.position.z;
      const distance = Math.sqrt(dx * dx + dz * dz);

      if (distance < pickupRange) {
        // Dispose geometries and non-shared materials before removing
        item.traverse((child) => {
          if (child instanceof THREE.Mesh) {
            child.geometry.dispose();
            const mat = child.material;
            // Only dispose materials that are not shared module-level cached ones
            if (mat && mat !== DROPPED_ITEM_GLOW_MAT && mat !== DROPPED_ITEM_DEFAULT_MAT) {
              if (Array.isArray(mat)) {
                for (const m of mat) m.dispose();
              } else {
                mat.dispose();
              }
            }
          }
        });
        this.scene.remove(item);
        this.droppedItems.splice(i, 1);
        soundSystem.playPickup();
        return { picked: true, itemType: item.userData.itemType };
      }
    }
    return null;
  }

  private updateDroppedObjectPhysics(obj: THREE.Group, delta: number) {
    if (obj.userData.grounded) {
      // Gentle rotation + bobbing with per-item phase offset
      obj.rotation.y += delta * 0.5;
      if (obj.userData.bobPhase === undefined) {
        obj.userData.bobPhase = Math.random() * Math.PI * 2;
      }
      const bobTime = (performance.now() / 1000) * 2;
      const baseY = obj.userData.groundedY ?? obj.position.y;
      if (obj.userData.groundedY === undefined) obj.userData.groundedY = obj.position.y;
      obj.position.y = baseY + Math.sin(bobTime + obj.userData.bobPhase) * 0.03;
      return;
    }

    // Apply gravity
    obj.userData.velocityY -= 15 * delta;

    // Compute new positions
    const newY = obj.position.y + obj.userData.velocityY * delta;
    const newX = obj.position.x + obj.userData.velocityX * delta;
    const newZ = obj.position.z + obj.userData.velocityZ * delta;

    // Check Y collision against map objects
    if (obj.userData.velocityY < 0) {
      const testBoxY = new THREE.Box3().setFromObject(obj);
      const deltaY = obj.userData.velocityY * delta;
      testBoxY.translate(new THREE.Vector3(0, deltaY, 0));
      let landedOnObject = false;
      for (const collider of this.mapColliders) {
        if (testBoxY.intersectsBox(collider) && collider.max.y <= obj.position.y) {
          obj.position.y = collider.max.y + 0.1;
          obj.userData.velocityY = 0;
          obj.userData.velocityX = 0;
          obj.userData.velocityZ = 0;
          obj.userData.grounded = true;
          landedOnObject = true;
          break;
        }
      }
      if (landedOnObject) return;
    }

    // Floor collision
    if (newY <= 0.1) {
      obj.position.y = 0.1;
      obj.userData.velocityY = 0;
      obj.userData.velocityX = 0;
      obj.userData.velocityZ = 0;
      obj.userData.grounded = true;
    } else {
      obj.position.y = newY;
    }

    // Horizontal movement with map collision check
    if (!obj.userData.grounded) {
      // Check X collision
      const testBoxX = new THREE.Box3().setFromObject(obj);
      testBoxX.translate(new THREE.Vector3(obj.userData.velocityX * delta, 0, 0));
      let hitX = false;
      for (const collider of this.mapColliders) {
        if (testBoxX.intersectsBox(collider)) { hitX = true; break; }
      }
      if (!hitX) obj.position.x = newX;
      else obj.userData.velocityX = 0;

      // Check Z collision
      const testBoxZ = new THREE.Box3().setFromObject(obj);
      testBoxZ.translate(new THREE.Vector3(0, 0, obj.userData.velocityZ * delta));
      let hitZ = false;
      for (const collider of this.mapColliders) {
        if (testBoxZ.intersectsBox(collider)) { hitZ = true; break; }
      }
      if (!hitZ) obj.position.z = newZ;
      else obj.userData.velocityZ = 0;
    }

    // Apply friction to horizontal velocity
    obj.userData.velocityX *= (1 - 3 * delta);
    obj.userData.velocityZ *= (1 - 3 * delta);

    // Slow rotation while in air
    obj.rotation.y += delta * 2;
  }

  private meleeAttack(type: 'shiv' | 'baton') {
    if (this.isPunching || this.punchCooldown > 0 || this.isDead || this.isUsingConsumable) return;

    this.isPunching = true;
    this.punchCooldown = this.punchCooldownTime;

    if (type === 'shiv') {
      soundSystem.playShivAttack();
    } else {
      soundSystem.playBatonAttack();
    }

    this.hands.startMeleeAttack();

    setTimeout(() => {
      this.checkPunchHit();
      this.isPunching = false;
    }, 150);
  }

  equipItem(itemType: string) {
    // If weapon is active, put it away first
    if (this.weapon) {
      this.putAwayWeapon();
    }

    this.heldItemType = itemType;
    this.hands.setHeldItem(itemType);
    this.shieldEquipped = itemType === 'item_shield';

    // Set melee damage multipliers
    if (itemType === 'item_shiv') {
      this.punchDamage = 40; // x2 of base 20
    } else if (itemType === 'item_baton') {
      this.punchDamage = 30; // x1.5 of base 20
    } else {
      this.punchDamage = 20; // reset to base
    }

    // If flashlight was on and we're switching away, remove the light
    if (itemType !== 'item_flashlight' && this.flashlight) {
      this.camera.remove(this.flashlight);
      this.camera.remove(this.flashlight.target);
      this.flashlight = null;
      this.flashlightOn = false;
    }
  }

  unequipItem() {
    if (this.flashlight) {
      this.camera.remove(this.flashlight);
      this.camera.remove(this.flashlight.target);
      this.flashlight = null;
      this.flashlightOn = false;
    }
    this.heldItemType = 'none';
    this.shieldEquipped = false;
    this.punchDamage = 20; // reset to base
    this.hands.setHeldItem('none');
  }

  private toggleFlashlight() {
    if (this.isDead) return;
    this.flashlightOn = !this.flashlightOn;
    soundSystem.playFlashlightToggle();
    this.hands.startFlashlightToggle();

    if (this.flashlightOn) {
      this.flashlight = new THREE.SpotLight(0xffffff, 2, 30, Math.PI / 6, 0.3, 1);
      this.flashlight.position.set(0, 0, -0.5);
      this.flashlight.target.position.set(0, 0, -5);
      this.camera.add(this.flashlight);
      this.camera.add(this.flashlight.target);
    } else {
      if (this.flashlight) {
        this.camera.remove(this.flashlight);
        this.camera.remove(this.flashlight.target);
        this.flashlight = null;
      }
    }
  }

  useConsumable(itemType: string) {
    if (this.isUsingConsumable || this.isDead) return;

    this.isUsingConsumable = true;
    this.consumableType = itemType;

    if (itemType === 'item_medkit') {
      this.consumableDuration = 2;
      this.hands.startUseAnimation('medkit');
    } else if (itemType === 'item_bandage') {
      this.consumableDuration = 3;
      this.hands.startUseAnimation('bandage');
    }
    this.consumableTimer = 0;
  }

  takeDamage(damage: number) {
    if (this.isDead) return;

    // Shield blocks all damage while equipped
    if (this.shieldEquipped) {
      soundSystem.playShieldBlock();
      return;
    }

    // Armor absorbs damage first
    if (this.armorEquipped && this.armorHp > 0) {
      if (damage <= this.armorHp) {
        this.armorHp -= damage;
        damage = 0;
      } else {
        damage -= this.armorHp;
        this.armorHp = 0;
      }
      if (this.armorHp <= 0) {
        this.armorEquipped = false;
        this.armorHp = 0;
        soundSystem.playArmorBreak();
      }
    }

    if (damage > 0) {
      this.hp = Math.max(0, this.hp - damage);
    }
    
    if (this.onHit) this.onHit(damage);
    
    if (this.hp <= 0) {
      this.die();
    }
    
    this.notifyStateChange();
  }

  private die() {
    this.isDead = true;
    if (this.onDeath) this.onDeath();

    // Clean up equipped item (flashlight, shield, etc.)
    this.unequipItem();
    
    // Выбрасываем оружие при смерти (check storedWeapon too)
    if (this.weapon || this.storedWeapon) {
      this.dropWeapon();
    }
  }

  heal(amount: number) {
    if (this.isDead) return;
    this.hp = Math.min(this.maxHp, this.hp + amount);
    this.notifyStateChange();
  }

  equipArmor() {
    this.armorEquipped = true;
    this.armorHp = this.maxArmorHp;
    this.notifyStateChange();
  }

  unequipArmor() {
    this.armorEquipped = false;
    this.armorHp = 0;
    this.notifyStateChange();
  }

  respawn() {
    this.hp = this.maxHp;
    this.isDead = false;
    this.heldItemType = 'none';
    this.shieldEquipped = false;
    this.armorEquipped = false;
    this.armorHp = 0;
    this.bandageRegenActive = false;
    this.bandageHealAccumulator = 0;
    this.isUsingConsumable = false;
    this.notifyStateChange();
  }

  private notifyStateChange() {
    if (this.onStateChange) {
      this.onStateChange(this.getState());
    }
  }

  getState(): CombatState {
    return {
      hp: this.hp,
      maxHp: this.maxHp,
      hasWeapon: this.weapon !== null,
      ammo: this.weapon?.stats.currentAmmo ?? 0,
      maxAmmo: this.weapon?.stats.maxAmmo ?? 0,
      isDead: this.isDead,
      isReloading: this.weapon?.isCurrentlyReloading() ?? false,
      armorHp: this.armorHp,
      maxArmorHp: this.maxArmorHp,
      armorEquipped: this.armorEquipped,
    };
  }

  update(delta: number) {
    // Обновляем кулдаун удара
    if (this.punchCooldown > 0) {
      this.punchCooldown -= delta;
    }

    // Reset consecutive shots after 300ms of not firing
    if (this.consecutiveShots > 0 && performance.now() - this.lastShotTime > 300) {
      this.consecutiveShots = 0;
    }

    // Consumable use timer
    if (this.isUsingConsumable) {
      // Cancel consumable if player died during use
      if (this.isDead) {
        this.isUsingConsumable = false;
        this.consumableType = '';
      } else {
        this.consumableTimer += delta;
        if (this.consumableTimer >= this.consumableDuration) {
          this.isUsingConsumable = false;
          if (this.consumableType === 'item_medkit') {
            this.heal(50);
            soundSystem.playHeal();
            this.onItemUsed?.(this.consumableType);
          } else if (this.consumableType === 'item_bandage') {
            soundSystem.playBandageWrap();
            this.bandageRegenActive = true;
            this.bandageRegenTimer = 0;
            this.bandageHealAccumulator = 0;
            this.onItemUsed?.(this.consumableType);
          }
          this.consumableType = '';
        }
      }
    }

    // Bandage regen over time (+3 HP/sec for ~7 seconds = +20 total)
    if (this.bandageRegenActive) {
      this.bandageRegenTimer += delta;
      if (this.bandageRegenTimer < 7) {
        this.bandageHealAccumulator += 3 * delta;
        while (this.bandageHealAccumulator >= 1.0) {
          this.heal(1);
          this.bandageHealAccumulator -= 1.0;
        }
      } else {
        this.bandageRegenActive = false;
        this.bandageHealAccumulator = 0;
      }
    }

    // Automatic fire while holding mouse button (only for auto weapons)
    if (this.isMouseDown && this.weapon && document.pointerLockElement !== null) {
      if (this.weapon.stats.fireMode === 'auto') {
        this.shoot();
      }
    }
    
    // Обновляем оружие
    if (this.weapon) {
      const wasReloading = this.weapon.isCurrentlyReloading();
      this.weapon.update(delta, this._isMoving, this._isSprinting);
      const isReloading = this.weapon.isCurrentlyReloading();
      // Обновляем UI при смене состояния перезарядки
      if (wasReloading !== isReloading || (wasReloading && isReloading)) {
        this.notifyStateChange();
      }
    }
    
    // Вращение выброшенного оружия (для визуала)
    for (const dropped of this.droppedWeapons) {
      this.updateDroppedObjectPhysics(dropped, delta);
    }

    // Update dropped items physics
    for (const item of this.droppedItems) {
      this.updateDroppedObjectPhysics(item, delta);
    }

    // Update impact particles
    for (let i = this.impactParticles.length - 1; i >= 0; i--) {
      const p = this.impactParticles[i];
      p.userData.lifetime += delta;
      p.position.x += p.userData.velocityX * delta;
      p.position.y += p.userData.velocityY * delta;
      p.position.z += p.userData.velocityZ * delta;
      // Apply gravity
      p.userData.velocityY -= 9.8 * delta;

      if (p.userData.lifetime >= p.userData.maxLifetime) {
        this.scene.remove(p);
        p.geometry.dispose();
        (p.material as THREE.Material).dispose();
        this.impactParticles.splice(i, 1);
      }
    }

    // Update tracers
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const t = this.tracers[i];
      t.userData.lifetime += delta;
      if (t.userData.lifetime >= t.userData.maxLifetime) {
        this.scene.remove(t);
        t.geometry.dispose();
        (t.material as THREE.Material).dispose();
        this.tracers.splice(i, 1);
      }
    }

    // Update shell casings
    for (let i = this.shellCasings.length - 1; i >= 0; i--) {
      const c = this.shellCasings[i];

      // Apply gravity
      c.userData.velocityY -= 15 * delta;

      // Move by velocity
      c.position.x += c.userData.velocityX * delta;
      c.position.y += c.userData.velocityY * delta;
      c.position.z += c.userData.velocityZ * delta;

      // Apply spin rotation
      c.rotation.x += c.userData.spinX * delta;
      c.rotation.z += c.userData.spinZ * delta;

      // Ground collision
      if (c.position.y <= 0 && !c.userData.bounced) {
        c.userData.bounced = true;
        c.userData.velocityY = -c.userData.velocityY * 0.3;
        c.userData.velocityX *= 0.3;
        c.userData.velocityZ *= 0.3;
        soundSystem.playShellCasing();
      } else if (c.position.y <= 0 && c.userData.bounced) {
        c.position.y = 0.012;
        c.userData.velocityX = 0;
        c.userData.velocityY = 0;
        c.userData.velocityZ = 0;
        c.userData.spinX = 0;
        c.userData.spinZ = 0;
      }

      // Reduce lifetime
      c.userData.lifetime -= delta;
      if (c.userData.lifetime <= 0) {
        this.scene.remove(c);
        c.geometry.dispose();
        (c.material as THREE.Material).dispose();
        this.shellCasings.splice(i, 1);
      }
    }

    // Update weapon smoke particles
    if (this.weapon) {
      this.weapon.updateSmoke(delta);
    }
  }

  dispose() {
    document.removeEventListener('mousedown', this.boundMouseDown);
    document.removeEventListener('mouseup', this.boundMouseUp);
    document.removeEventListener('keydown', this.boundKeyDown);
  }
}
