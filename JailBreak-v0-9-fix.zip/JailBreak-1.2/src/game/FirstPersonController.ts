import * as THREE from 'three';

export class FirstPersonController {
  public camera: THREE.PerspectiveCamera;
  public velocity: THREE.Vector3 = new THREE.Vector3();
  public direction: THREE.Vector3 = new THREE.Vector3();

  private moveForward = false;
  private moveBackward = false;
  private moveLeft = false;
  private moveRight = false;
  private canJump = true;
  private isCrouching = false;
  private isSprinting = false;

  private euler = new THREE.Euler(0, 0, 0, 'YXZ');
  private readonly PI_2 = Math.PI / 2;

  private walkSpeed = 4.5;
  private sprintSpeed = 8;
  private crouchSpeed = 2.5;
  private jumpForce = 8;
  private gravity = 25;
  private standHeight = 1.7;
  private crouchHeight = 1.0;
  private currentHeight = 1.7;

  // Fall damage
  private lastGroundY = 0;
  private wasInAir = false;
  private fallDamageThreshold = 5; // min fall distance for damage
  private fallDamageMultiplier = 8; // damage per unit fallen beyond threshold

  // Climbing
  private climbing = false;

  // Camera effects
  public cameraShakeAmount = 0;
  public recoilPitch = 0;

  // Terrain integration
  public terrainHeightFn: ((x: number, z: number) => number) | null = null;
  public speedMultiplier: number = 1.0;

  private prevFeetY = 0;
  private prevHeadY = 0;
  private colliders: THREE.Box3[] = [];
  private pointerLockEnabled = true;

  private boundOnKeyDown: (e: KeyboardEvent) => void;
  private boundOnKeyUp: (e: KeyboardEvent) => void;
  private boundOnMouseMove: (e: MouseEvent) => void;
  private boundOnClick: (e: MouseEvent) => void;

  // Callbacks
  public onFallDamage?: (damage: number) => void;
  public onLand?: () => void;

  constructor(camera: THREE.PerspectiveCamera) {
    this.camera = camera;
    this.camera.position.set(0, this.standHeight, 5);
    this.lastGroundY = this.standHeight;

    this.boundOnKeyDown = this.onKeyDown.bind(this);
    this.boundOnKeyUp = this.onKeyUp.bind(this);
    this.boundOnMouseMove = this.onMouseMove.bind(this);
    this.boundOnClick = this.onClick.bind(this);

    this.setupEventListeners();
  }

  private resetMovement() {
    this.moveForward = false;
    this.moveBackward = false;
    this.moveLeft = false;
    this.moveRight = false;
    this.isSprinting = false;
  }

  setColliders(colliders: THREE.Box3[]) {
    this.colliders = colliders;
  }

  /** Initialize prevFeetY to current feet position - call after setting spawn position */
  initFeetPosition() {
    this.prevFeetY = this.camera.position.y - this.currentHeight;
  }

  private setupEventListeners() {
    document.addEventListener('keydown', this.boundOnKeyDown);
    document.addEventListener('keyup', this.boundOnKeyUp);
    document.addEventListener('mousemove', this.boundOnMouseMove);
    document.addEventListener('click', this.boundOnClick);
    window.addEventListener('blur', () => this.resetMovement());
    document.addEventListener('pointerlockchange', () => { if (!this.isLocked) this.resetMovement(); });
  }

  private get isLocked(): boolean { return document.pointerLockElement !== null; }

  setPointerLockEnabled(enabled: boolean) { this.pointerLockEnabled = enabled; }

  getCrouching() { return this.isCrouching; }
  getSprinting() { return this.isSprinting; }
  isPressingForward(): boolean { return this.moveForward; }

  setClimbing(climbing: boolean) {
    this.climbing = climbing;
    if (climbing) {
      this.velocity.y = 0;
      this.canJump = true;
    }
  }

  private onClick() {
    if (!this.isLocked && this.pointerLockEnabled) document.body.requestPointerLock();
  }

  addRecoil(pitch: number, yaw = 0) {
    this.recoilPitch += pitch;
    if (yaw !== 0) {
      this.euler.setFromQuaternion(this.camera.quaternion);
      this.euler.y += yaw;
      this.camera.quaternion.setFromEuler(this.euler);
    }
  }

  private onMouseMove(event: MouseEvent) {
    if (!this.isLocked) return;
    this.euler.setFromQuaternion(this.camera.quaternion);
    this.euler.y -= (event.movementX || 0) * 0.002;
    this.euler.x -= (event.movementY || 0) * 0.002;
    this.euler.x = Math.max(-this.PI_2 + 0.01, Math.min(this.PI_2 - 0.01, this.euler.x));
    this.camera.quaternion.setFromEuler(this.euler);
  }

  private onKeyDown(event: KeyboardEvent) {
    if (event.code === 'Tab') { event.preventDefault(); return; }
    switch (event.code) {
      case 'KeyW': case 'ArrowUp': this.moveForward = true; break;
      case 'KeyS': case 'ArrowDown': this.moveBackward = true; break;
      case 'KeyA': case 'ArrowLeft': this.moveLeft = true; break;
      case 'KeyD': case 'ArrowRight': this.moveRight = true; break;
      case 'Space':
        if (this.canJump && this.isLocked) {
          this.velocity.y = this.jumpForce;
          this.canJump = false;
          this.wasInAir = true;
        }
        break;
      case 'ShiftLeft': case 'ShiftRight':
        if (!this.isCrouching) this.isSprinting = true;
        break;
      case 'ControlLeft': case 'ControlRight':
        this.isCrouching = true;
        this.isSprinting = false;
        break;
    }
  }

  private onKeyUp(event: KeyboardEvent) {
    switch (event.code) {
      case 'KeyW': case 'ArrowUp': this.moveForward = false; break;
      case 'KeyS': case 'ArrowDown': this.moveBackward = false; break;
      case 'KeyA': case 'ArrowLeft': this.moveLeft = false; break;
      case 'KeyD': case 'ArrowRight': this.moveRight = false; break;
      case 'ShiftLeft': case 'ShiftRight': this.isSprinting = false; break;
      case 'ControlLeft': case 'ControlRight': this.isCrouching = false; break;
    }
  }

  private checkCollision(newPosition: THREE.Vector3): boolean {
    const h = this.currentHeight;
    // Small feet clearance to avoid z-fighting with floor seams but catch real objects
    const feetClearance = 0.05;
    const feetY = newPosition.y - h;
    const playerBox = new THREE.Box3(
      new THREE.Vector3(newPosition.x - 0.3, feetY + feetClearance, newPosition.z - 0.3),
      new THREE.Vector3(newPosition.x + 0.3, newPosition.y + 0.2, newPosition.z + 0.3)
    );
    for (const collider of this.colliders) {
      // Skip colliders the player is currently standing on top of.
      // If the collider's top is at or below the player's feet + tolerance, it should
      // not block horizontal movement (player is walking on it).
      if (collider.max.y <= feetY + 0.1) continue;
      if (playerBox.intersectsBox(collider)) {
        return true;
      }
    }
    return false;
  }

  isMoving(): boolean { return this.moveForward || this.moveBackward || this.moveLeft || this.moveRight; }

  update(delta: number) {
    const MAX_STEP = 1 / 60; // Never move more than 1/60s worth in one step
    const steps = Math.ceil(delta / MAX_STEP);
    const subDelta = delta / steps;

    for (let i = 0; i < steps; i++) {
      this.updateStep(subDelta);
    }
  }

  private updateStep(delta: number) {
    // Track previous frame feet position for fall-through detection
    this.prevFeetY = this.camera.position.y - this.currentHeight;
    // Track previous head position for ceiling collision
    this.prevHeadY = this.camera.position.y + 0.2;

    // Height transition (crouch)
    const targetHeight = this.isCrouching ? this.crouchHeight : this.standHeight;
    this.currentHeight += (targetHeight - this.currentHeight) * delta * 10;

    // Gravity always applies (even when pointer lock is lost, e.g. inventory open)
    if (!this.climbing) {
      this.velocity.y -= this.gravity * delta;
    }

    // Player input (movement) only when pointer is locked
    let moveX = 0;
    let moveZ = 0;
    if (this.isLocked) {
      // Speed
      let speed = this.walkSpeed;
      if (this.isSprinting && this.isMoving()) speed = this.sprintSpeed;
      if (this.isCrouching) speed = this.crouchSpeed;
      speed *= this.speedMultiplier;

      // Direction
      this.direction.z = Number(this.moveForward) - Number(this.moveBackward);
      this.direction.x = Number(this.moveRight) - Number(this.moveLeft);
      this.direction.normalize();

      const forward = new THREE.Vector3();
      this.camera.getWorldDirection(forward);
      forward.y = 0; forward.normalize();
      const right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0));

      moveX = (forward.x * this.direction.z + right.x * this.direction.x) * speed * delta;
      moveZ = (forward.z * this.direction.z + right.z * this.direction.x) * speed * delta;
    }

    // Horizontal collision with step-up
    const stepUpHeight = 0.55; // Maximum height player can step up (stairs are 0.5 per step)

    const newPosX = this.camera.position.clone(); newPosX.x += moveX;
    if (this.checkCollision(newPosX)) {
      // Try stepping up
      const steppedX = newPosX.clone();
      steppedX.y += stepUpHeight;
      if (!this.checkCollision(steppedX)) {
        // Can step up - find the exact height needed
        this.camera.position.x = newPosX.x;
        const feetYForStep = this.camera.position.y - this.currentHeight;
        for (const collider of this.colliders) {
          if (this.camera.position.x + 0.3 > collider.min.x &&
              this.camera.position.x - 0.3 < collider.max.x &&
              this.camera.position.z + 0.3 > collider.min.z &&
              this.camera.position.z - 0.3 < collider.max.z &&
              collider.max.y > feetYForStep &&
              collider.max.y <= feetYForStep + stepUpHeight) {
            this.camera.position.y = collider.max.y + this.currentHeight;
            this.velocity.y = 0;
            this.canJump = true;
            break;
          }
        }
      }
      // else: blocked, don't move
    } else {
      this.camera.position.x = newPosX.x;
    }

    const newPosZ = this.camera.position.clone(); newPosZ.z += moveZ;
    if (this.checkCollision(newPosZ)) {
      // Try stepping up
      const steppedZ = newPosZ.clone();
      steppedZ.y += stepUpHeight;
      if (!this.checkCollision(steppedZ)) {
        // Can step up - find the exact height needed
        this.camera.position.z = newPosZ.z;
        const feetYForStep = this.camera.position.y - this.currentHeight;
        for (const collider of this.colliders) {
          if (this.camera.position.x + 0.3 > collider.min.x &&
              this.camera.position.x - 0.3 < collider.max.x &&
              this.camera.position.z + 0.3 > collider.min.z &&
              this.camera.position.z - 0.3 < collider.max.z &&
              collider.max.y > feetYForStep &&
              collider.max.y <= feetYForStep + stepUpHeight) {
            this.camera.position.y = collider.max.y + this.currentHeight;
            this.velocity.y = 0;
            this.canJump = true;
            break;
          }
        }
      }
      // else: blocked, don't move
    } else {
      this.camera.position.z = newPosZ.z;
    }

    // Vertical
    this.camera.position.y += this.velocity.y * delta;

    // Ceiling collision check: prevent head from passing through colliders from below
    const headY = this.camera.position.y + 0.2;
    const feetYCeiling = this.camera.position.y - this.currentHeight;
    for (const collider of this.colliders) {
      // Check horizontal overlap
      if (this.camera.position.x + 0.3 > collider.min.x &&
          this.camera.position.x - 0.3 < collider.max.x &&
          this.camera.position.z + 0.3 > collider.min.z &&
          this.camera.position.z - 0.3 < collider.max.z) {
        // Head entered collider from below
        if (headY > collider.min.y &&
            this.prevHeadY <= collider.min.y &&
            collider.min.y > feetYCeiling + 1.0) {
          this.camera.position.y = collider.min.y - 0.2;
          this.velocity.y = 0;
          break;
        }
      }
    }

    // Persistent ceiling overlap ejection (handles spawn/teleport inside ceiling)
    const headYAfter = this.camera.position.y + 0.2;
    for (const collider of this.colliders) {
      if (this.camera.position.x + 0.3 > collider.min.x &&
          this.camera.position.x - 0.3 < collider.max.x &&
          this.camera.position.z + 0.3 > collider.min.z &&
          this.camera.position.z - 0.3 < collider.max.z) {
        if (headYAfter > collider.min.y && headYAfter < collider.max.y &&
            collider.min.y > (this.camera.position.y - this.currentHeight) + 1.0) {
          this.camera.position.y = collider.min.y - 0.2;
          if (this.velocity.y > 0) this.velocity.y = 0;
          break;
        }
      }
    }

    // Skip ground/landing logic while climbing (velocity controlled externally)
    if (this.climbing) {
      // Ceiling check only
      if (this.camera.position.y > 100) { this.camera.position.y = 100; this.velocity.y = 0; }
      return;
    }

    // Check if player lands on top of a collider
    const feetY = this.camera.position.y - this.currentHeight;
    let groundY = this.terrainHeightFn ? this.terrainHeightFn(this.camera.position.x, this.camera.position.z) : 0; // terrain or default floor level
    for (const collider of this.colliders) {
      // Check if player is horizontally overlapping this collider
      if (this.camera.position.x + 0.3 > collider.min.x &&
          this.camera.position.x - 0.3 < collider.max.x &&
          this.camera.position.z + 0.3 > collider.min.z &&
          this.camera.position.z - 0.3 < collider.max.z) {
        // Player's feet are at or below the top of this collider and within range, and falling
        if (feetY <= collider.max.y && (feetY > collider.min.y || this.prevFeetY >= collider.max.y) && this.velocity.y <= 0) {
          if (collider.max.y > groundY) {
            groundY = collider.max.y;
          }
        }
      }
    }

    // Apply ground (either collider top or floor at y=0)
    const minCameraY = groundY + this.currentHeight;
    if (this.camera.position.y < minCameraY) {
      // Fall damage
      if (this.wasInAir) {
        const fallDist = this.lastGroundY - this.camera.position.y;
        if (fallDist > this.fallDamageThreshold) {
          const damage = Math.round((fallDist - this.fallDamageThreshold) * this.fallDamageMultiplier);
          this.onFallDamage?.(damage);
        }
        this.onLand?.();
        this.wasInAir = false;
      }
      this.camera.position.y = minCameraY;
      this.velocity.y = 0;
      this.canJump = true;
      this.lastGroundY = this.camera.position.y;
    } else if (!this.canJump && this.velocity.y < -2) {
      this.wasInAir = true;
    }

    // Ceiling
    if (this.camera.position.y > 100) { this.camera.position.y = 100; this.velocity.y = 0; }

    // Camera recoil recovery
    if (this.recoilPitch > 0) {
      this.euler.setFromQuaternion(this.camera.quaternion);
      this.euler.x -= this.recoilPitch * delta * 0.5;
      this.recoilPitch -= this.recoilPitch * delta * 8;
      if (this.recoilPitch < 0.001) this.recoilPitch = 0;
      this.camera.quaternion.setFromEuler(this.euler);
    }

    // Camera shake recovery
    if (this.cameraShakeAmount > 0) {
      this.cameraShakeAmount -= delta * 3;
      if (this.cameraShakeAmount < 0) this.cameraShakeAmount = 0;
    }
  }

  dispose() {
    document.removeEventListener('keydown', this.boundOnKeyDown);
    document.removeEventListener('keyup', this.boundOnKeyUp);
    document.removeEventListener('mousemove', this.boundOnMouseMove);
    document.removeEventListener('click', this.boundOnClick);
  }
}
